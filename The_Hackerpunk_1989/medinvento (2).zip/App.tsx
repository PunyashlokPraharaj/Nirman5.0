import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  UserRole, 
  ViewState, 
  User, 
  Medicine, 
  MedicineType,
  ComplianceReport,
  InventoryLog
} from './types';
import { INITIAL_MEDICINES, MOCK_USERS } from './services/mockService';
import { Icons } from './components/Icons';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';

// --- COMPONENTS ---

// 1. Sidebar Component
const Sidebar = ({ 
  user, 
  currentView, 
  onChangeView, 
  onLogout,
  isOpen,
  toggleSidebar
}: { 
  user: User, 
  currentView: ViewState, 
  onChangeView: (v: ViewState) => void, 
  onLogout: () => void,
  isOpen: boolean,
  toggleSidebar: () => void
}) => {
  const menuItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: Icons.Home, roles: [UserRole.OWNER, UserRole.EMPLOYEE, UserRole.GOVT] },
    { id: 'INVENTORY', label: 'Inventory', icon: Icons.Package, roles: [UserRole.OWNER, UserRole.EMPLOYEE] },
    { id: 'SCANNER', label: 'Scanner', icon: Icons.Barcode, roles: [UserRole.OWNER, UserRole.EMPLOYEE] },
    { id: 'GOVT_PORTAL', label: 'Compliance & Sync', icon: Icons.ShieldCheck, roles: [UserRole.GOVT] },
    { id: 'SETTINGS', label: 'Settings', icon: Icons.Settings, roles: [UserRole.OWNER, UserRole.EMPLOYEE, UserRole.GOVT] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(user.role));

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={toggleSidebar}
        />
      )}
      
      <aside className={`
        fixed inset-y-0 left-0 z-30 w-72 bg-white dark:bg-med-surface border-r border-gray-200 dark:border-gray-800 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0 flex flex-col
      `}>
        <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center space-x-3 text-med-deep dark:text-med-blue font-bold text-xl">
            <div className="bg-med-blue/10 dark:bg-med-blue/20 p-2 rounded-lg">
              <Icons.Activity className="w-6 h-6 text-med-blue" />
            </div>
            <span className="tracking-tight">MedInvento Pro</span>
          </div>
          <button onClick={toggleSidebar} className="md:hidden text-gray-400 hover:text-gray-600">
            <Icons.X />
          </button>
        </div>

        <div className="px-6 py-4">
           <div className="bg-med-gray dark:bg-med-elevated p-3 rounded-xl flex items-center space-x-3 mb-2">
             <div className="w-10 h-10 rounded-full bg-med-blue flex items-center justify-center text-white font-bold text-lg shadow-md">
               {user.name.charAt(0)}
             </div>
             <div className="overflow-hidden">
               <p className="text-sm font-bold text-gray-900 dark:text-white truncate">{user.name}</p>
               <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{user.role.toLowerCase()}</p>
             </div>
           </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto no-scrollbar">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onChangeView(item.id as ViewState);
                  if (window.innerWidth < 768) toggleSidebar();
                }}
                className={`w-full flex items-center space-x-3 px-4 py-3.5 rounded-xl transition-all duration-200 group ${
                  isActive 
                    ? 'bg-med-blue text-white shadow-lg shadow-med-blue/30' 
                    : 'text-gray-600 dark:text-gray-400 hover:bg-med-aqua/10 hover:text-med-deep dark:hover:bg-gray-800 dark:hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-med-deep dark:group-hover:text-white'}`} />
                <span className="font-medium text-sm">{item.label}</span>
                {isActive && <Icons.ChevronRight className="w-4 h-4 ml-auto opacity-50" />}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-100 dark:border-gray-800">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-2 px-4 py-3 text-med-red hover:bg-med-red/5 dark:hover:bg-med-red/10 rounded-xl transition-colors font-medium text-sm"
          >
            <Icons.LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};

// 2. StatCard Component
const StatCard = ({ title, value, subtext, icon: Icon, colorClass, textColor }: any) => (
  <div className="bg-white dark:bg-med-surface rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-xl ${colorClass}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <span className="text-xs font-medium text-gray-400 bg-gray-50 dark:bg-gray-800 px-2 py-1 rounded-full">Today</span>
    </div>
    <h3 className={`text-2xl font-bold ${textColor || 'text-gray-900 dark:text-white'}`}>{value}</h3>
    <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mt-1">{title}</p>
    {subtext && <p className="text-xs text-gray-400 mt-2 flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-gray-300 mr-2"></span>{subtext}</p>}
  </div>
);

// 3. Government Portal View (Hierarchical)
const GovernmentPortalView = ({ allMedicines }: { allMedicines: Medicine[] }) => {
  const [level, setLevel] = useState<'CITIES' | 'STORES' | 'MEDICINES'>('CITIES');
  const [selectedCity, setSelectedCity] = useState<{ id: string, name: string } | null>(null);
  const [selectedStore, setSelectedStore] = useState<{ id: string, name: string, license: string, address: string, score: number } | null>(null);

  // Mock Data for Govt Hierarchy
  const CITIES = [
    { id: '1', name: 'New Delhi', pharmacies: 142, compliance: 92, risk: 'Low' },
    { id: '2', name: 'Mumbai', pharmacies: 189, compliance: 88, risk: 'Moderate' },
    { id: '3', name: 'Bangalore', pharmacies: 110, compliance: 95, risk: 'Low' },
    { id: '4', name: 'Chennai', pharmacies: 98, compliance: 91, risk: 'Low' },
    { id: '5', name: 'Kolkata', pharmacies: 130, compliance: 84, risk: 'High' },
  ];

  const STORES = [
    { id: 's1', name: 'City Central Pharmacy', license: 'DL-2023-001', address: '12, MG Road', score: 98 },
    { id: 's2', name: 'Apollo Pharmacy', license: 'DL-2023-045', address: 'Sector 4, Market Complex', score: 92 },
    { id: 's3', name: 'Wellness Forever', license: 'DL-2023-089', address: 'Near Station Road', score: 85 },
    { id: 's4', name: 'MedPlus Store', license: 'DL-2023-112', address: 'High Street, Block A', score: 78 },
  ];

  const handleCitySelect = (city: any) => {
    setSelectedCity(city);
    setLevel('STORES');
  };

  const handleStoreSelect = (store: any) => {
    setSelectedStore(store);
    setLevel('MEDICINES');
  };

  const goBack = () => {
    if (level === 'MEDICINES') {
      setLevel('STORES');
      setSelectedStore(null);
    } else if (level === 'STORES') {
      setLevel('CITIES');
      setSelectedCity(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in h-full flex flex-col">
      {/* Navigation Header */}
      <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400 bg-white dark:bg-med-surface p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800">
        <button 
          onClick={() => { setLevel('CITIES'); setSelectedCity(null); setSelectedStore(null); }}
          className={`hover:text-med-blue font-medium ${level === 'CITIES' ? 'text-med-blue font-bold' : ''}`}
        >
          All Cities
        </button>
        {level !== 'CITIES' && (
          <>
            <Icons.ChevronRight className="w-4 h-4" />
            <button 
              onClick={() => { setLevel('STORES'); setSelectedStore(null); }}
              className={`hover:text-med-blue font-medium ${level === 'STORES' ? 'text-med-blue font-bold' : ''}`}
            >
              {selectedCity?.name}
            </button>
          </>
        )}
        {level === 'MEDICINES' && (
          <>
            <Icons.ChevronRight className="w-4 h-4" />
            <span className="text-med-blue font-bold">{selectedStore?.name}</span>
          </>
        )}
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto">
        {level === 'CITIES' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CITIES.map((city) => (
              <div 
                key={city.id} 
                onClick={() => handleCitySelect(city)}
                className="bg-white dark:bg-med-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-lg hover:border-med-blue/30 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl group-hover:bg-med-blue group-hover:text-white transition-colors text-med-blue">
                    <Icons.MapPin className="w-6 h-6" />
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                    city.risk === 'Low' ? 'bg-green-100 text-green-700' : 
                    city.risk === 'Moderate' ? 'bg-yellow-100 text-yellow-700' : 
                    'bg-red-100 text-red-700'
                  }`}>
                    {city.risk} Risk
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">{city.name}</h3>
                <p className="text-sm text-gray-500 mb-6">{city.pharmacies} Registered Pharmacies</p>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Compliance Score</span>
                  <span className={`font-bold ${city.compliance > 90 ? 'text-green-600' : 'text-orange-500'}`}>
                    {city.compliance}%
                  </span>
                </div>
                <div className="w-full bg-gray-100 dark:bg-gray-700 h-2 rounded-full mt-2 overflow-hidden">
                  <div className={`h-full rounded-full ${city.compliance > 90 ? 'bg-green-500' : 'bg-orange-500'}`} style={{ width: `${city.compliance}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        )}

        {level === 'STORES' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
               <h3 className="text-xl font-bold text-gray-900 dark:text-white">Pharmacies in {selectedCity?.name}</h3>
               <button onClick={goBack} className="text-sm text-gray-500 hover:text-gray-700 flex items-center">
                 <Icons.ArrowRight className="w-4 h-4 mr-1 rotate-180" /> Back
               </button>
            </div>
            {STORES.map((store) => (
              <div 
                key={store.id}
                onClick={() => handleStoreSelect(store)}
                className="bg-white dark:bg-med-surface p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
              >
                 <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-med-gray dark:bg-gray-700 rounded-full flex items-center justify-center text-gray-500 group-hover:bg-med-blue group-hover:text-white transition-colors">
                       <Icons.Building className="w-6 h-6" />
                    </div>
                    <div>
                       <h4 className="font-bold text-gray-900 dark:text-white text-lg">{store.name}</h4>
                       <p className="text-sm text-gray-500">{store.address} • Lic: {store.license}</p>
                    </div>
                 </div>
                 <div className="text-right">
                    <div className="text-xs text-gray-400 mb-1">Audit Score</div>
                    <div className={`text-xl font-bold ${store.score > 90 ? 'text-green-600' : store.score > 80 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {store.score}/100
                    </div>
                 </div>
              </div>
            ))}
          </div>
        )}

        {level === 'MEDICINES' && (
          <div className="bg-white dark:bg-med-surface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
            <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Store Inventory Audit</h3>
                <p className="text-sm text-gray-500">Inspecting: <span className="font-semibold text-med-blue">{selectedStore?.name}</span></p>
              </div>
              <div className="flex gap-2">
                 <button className="px-4 py-2 bg-red-50 text-red-600 text-sm font-bold rounded-xl hover:bg-red-100 transition-colors">Flag Store</button>
                 <button className="px-4 py-2 bg-med-blue text-white text-sm font-bold rounded-xl hover:bg-med-deep transition-colors">Download Report</button>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 dark:bg-med-elevated text-gray-500 dark:text-gray-400 font-semibold text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-4">Medicine Name</th>
                    <th className="px-6 py-4">Batch No.</th>
                    <th className="px-6 py-4">Expiry</th>
                    <th className="px-6 py-4">Stock</th>
                    <th className="px-6 py-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {allMedicines.map((med) => {
                     const isExpired = new Date(med.expiryDate) < new Date();
                     const isLowStock = med.stockCount < med.minStockThreshold;
                     return (
                        <tr key={med.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                          <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{med.name}</td>
                          <td className="px-6 py-4 font-mono text-xs text-gray-600 dark:text-gray-400">{med.batchNumber}</td>
                          <td className={`px-6 py-4 text-sm font-bold ${isExpired ? 'text-red-600' : 'text-gray-600 dark:text-gray-400'}`}>
                            {new Date(med.expiryDate).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-gray-700 dark:text-gray-300">{med.stockCount}</td>
                          <td className="px-6 py-4">
                            {isExpired ? (
                               <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                 Expired
                               </span>
                            ) : isLowStock ? (
                               <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                 Low Stock
                               </span>
                            ) : (
                               <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                 Compliant
                               </span>
                            )}
                          </td>
                        </tr>
                     );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// 4. Barcode Scanner Component (New)
const BarcodeScanner = ({ onScan, onClose }: { onScan: (code: string) => void, onClose: () => void }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string>('');
  const [isSimulating, setIsSimulating] = useState(false);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        setError('Camera access denied. Please allow permissions.');
        console.error(err);
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleSimulateScan = () => {
    setIsSimulating(true);
    setTimeout(() => {
      onScan('8901234567890'); // Mock successful scan of Paracetamol
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
       <div className="p-4 flex justify-between items-center z-10 bg-gradient-to-b from-black/80 to-transparent">
          <div className="text-white font-bold flex items-center gap-2">
             <Icons.ScanLine className="w-6 h-6 text-med-blue" />
             <span>Scanner Active</span>
          </div>
          <button onClick={onClose} className="bg-white/20 p-2 rounded-full text-white hover:bg-white/30 backdrop-blur-md">
             <Icons.X className="w-6 h-6" />
          </button>
       </div>

       <div className="flex-1 relative flex items-center justify-center overflow-hidden">
          {error ? (
            <div className="text-white p-8 text-center max-w-md">
              <Icons.AlertTriangle className="w-16 h-16 mx-auto mb-6 text-med-red" />
              <h3 className="text-xl font-bold mb-2">Camera Error</h3>
              <p className="text-gray-300">{error}</p>
            </div>
          ) : (
            <>
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted
                className="absolute inset-0 w-full h-full object-cover"
              />
              
              {/* Overlay UI */}
              <div className="absolute inset-0 z-10">
                 {/* Darkened Borders */}
                 <div className="absolute top-0 left-0 right-0 h-[25%] bg-black/60 backdrop-blur-[2px]"></div>
                 <div className="absolute bottom-0 left-0 right-0 h-[35%] bg-black/60 backdrop-blur-[2px]"></div>
                 <div className="absolute top-[25%] left-0 w-[10%] h-[40%] bg-black/60 backdrop-blur-[2px]"></div>
                 <div className="absolute top-[25%] right-0 w-[10%] h-[40%] bg-black/60 backdrop-blur-[2px]"></div>
                 
                 {/* Scan Frame */}
                 <div className="absolute top-[25%] left-[10%] right-[10%] h-[40%] border-2 border-med-blue/50 rounded-lg shadow-[0_0_0_1px_rgba(255,255,255,0.1)]">
                   {isSimulating ? (
                     <div className="absolute inset-0 flex flex-col items-center justify-center bg-med-blue/20 backdrop-blur-sm animate-pulse">
                        <Icons.Loader2 className="w-12 h-12 text-white animate-spin" />
                        <p className="text-white font-bold mt-4 tracking-wider">PROCESSING...</p>
                     </div>
                   ) : (
                     <>
                        <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-med-blue -mt-1 -ml-1 rounded-tl-lg"></div>
                        <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-med-blue -mt-1 -mr-1 rounded-tr-lg"></div>
                        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-med-blue -mb-1 -ml-1 rounded-bl-lg"></div>
                        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-med-blue -mb-1 -mr-1 rounded-br-lg"></div>
                        <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-red-500 opacity-50 animate-pulse"></div>
                     </>
                   )}
                 </div>

                 <div className="absolute bottom-[40%] left-0 right-0 text-center">
                    <p className="text-white/80 text-sm font-medium drop-shadow-md">Align barcode within frame</p>
                 </div>
              </div>

              {/* Controls */}
              <div className="absolute bottom-12 left-0 right-0 z-20 flex flex-col items-center gap-6">
                 {!isSimulating && (
                   <button 
                      onClick={handleSimulateScan}
                      className="bg-white text-black px-6 py-3 rounded-full font-bold shadow-lg hover:bg-gray-200 transition-colors flex items-center gap-2"
                   >
                     <Icons.Zap className="w-5 h-5 text-yellow-600 fill-current" />
                     Simulate Scan
                   </button>
                 )}
                 <p className="text-xs text-white/50">Supports EAN-13, UPC-A, Code 128</p>
              </div>
            </>
          )}
       </div>
    </div>
  );
};

// 5. Inventory View with Highlighting (Existing Component)
const InventoryView = ({ 
  medicines, 
  onAddMedicine, 
  onDeleteMedicine,
  onUpdateStock,
  currentUser 
}: {
  medicines: Medicine[],
  onAddMedicine: (m: Medicine) => void,
  onDeleteMedicine: (id: string) => void,
  onUpdateStock: (id: string, newCount: number) => void,
  currentUser: User
}) => {
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'expiry' | 'name' | 'stock'>('name');
  
  const [newMed, setNewMed] = useState<Partial<Medicine>>({
    type: MedicineType.TABLET,
    stockCount: 0,
    minStockThreshold: 50,
    mrp: 0,
    gstPercentage: 12,
    hsnCode: ''
  });

  const getRowStyle = (med: Medicine) => {
    const daysToExpiry = (new Date(med.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    
    // Critical Expiry (< 30 days)
    if (daysToExpiry < 30) return 'bg-med-red/10 dark:bg-med-red/20 border-l-4 border-med-red';
    
    // Warning Expiry (< 90 days)
    if (daysToExpiry < 90) return 'bg-med-orange/10 dark:bg-med-orange/20 border-l-4 border-med-orange';
    
    // Low Stock
    if (med.stockCount < med.minStockThreshold) return 'bg-yellow-50 dark:bg-yellow-900/10 border-l-4 border-yellow-400';
    
    return 'hover:bg-gray-50 dark:hover:bg-gray-800/50 border-l-4 border-transparent';
  };

  const filtered = useMemo(() => {
    let result = medicines.filter(m => 
      (m.name.toLowerCase().includes(search.toLowerCase()) || 
       m.batchNumber.toLowerCase().includes(search.toLowerCase())) &&
      (filterType === 'ALL' || m.type === filterType)
    );

    if (sortBy === 'expiry') {
      result.sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
    } else if (sortBy === 'stock') {
      result.sort((a, b) => a.stockCount - b.stockCount);
    } else {
      result.sort((a, b) => a.name.localeCompare(b.name));
    }
    return result;
  }, [medicines, search, filterType, sortBy]);

  const handleAdd = () => {
    if (!newMed.name || !newMed.batchNumber) return;
    const med: Medicine = {
      id: Math.random().toString(36).substr(2, 9),
      name: newMed.name,
      saltComposition: newMed.saltComposition || '',
      manufacturer: newMed.manufacturer || 'Unknown',
      batchNumber: newMed.batchNumber,
      mrp: Number(newMed.mrp),
      sellingPrice: Number(newMed.mrp) * 0.9,
      stockCount: Number(newMed.stockCount),
      expiryDate: newMed.expiryDate || new Date().toISOString(),
      manufacturingDate: newMed.manufacturingDate || new Date().toISOString(),
      type: newMed.type as MedicineType,
      barcode: Math.floor(Math.random() * 1000000000000).toString(),
      gstPercentage: Number(newMed.gstPercentage),
      hsnCode: newMed.hsnCode,
      scheduleCategory: 'H',
      addedBy: currentUser.name,
      lastUpdated: new Date().toISOString(),
      minStockThreshold: Number(newMed.minStockThreshold)
    };
    onAddMedicine(med);
    setShowAddModal(false);
    setNewMed({ type: MedicineType.TABLET, stockCount: 0, minStockThreshold: 50, mrp: 0, gstPercentage: 12, hsnCode: '' });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-med-deep dark:text-white">Inventory Management</h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm">Real-time stock tracking and batch control</p>
        </div>
        
        <div className="flex flex-wrap gap-3 w-full xl:w-auto">
          <div className="relative flex-1 min-w-[200px]">
            <Icons.Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search (Name, Batch)..." 
              className="pl-9 pr-4 py-2.5 w-full border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-med-elevated text-gray-900 dark:text-white focus:ring-2 focus:ring-med-blue focus:outline-none shadow-sm text-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <select 
            className="px-4 py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-med-elevated text-gray-700 dark:text-gray-200 text-sm focus:outline-none"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="ALL">All Categories</option>
            {Object.values(MedicineType).map(t => <option key={t} value={t}>{t}</option>)}
          </select>

          <select 
            className="px-4 py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-med-elevated text-gray-700 dark:text-gray-200 text-sm focus:outline-none"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
          >
            <option value="name">Name (A-Z)</option>
            <option value="expiry">Expiry Date</option>
            <option value="stock">Stock Level</option>
          </select>

          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 bg-med-blue hover:bg-med-deep text-white px-5 py-2.5 rounded-xl transition-all shadow-md shadow-med-blue/20 text-sm font-semibold"
          >
            <Icons.Plus className="w-4 h-4" />
            <span>Add Medicine</span>
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-med-surface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-med-elevated text-gray-500 dark:text-gray-400 font-semibold text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Medicine Info</th>
                <th className="px-6 py-4">Batch / Exp</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Price (MRP)</th>
                <th className="px-6 py-4">Stock Control</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtered.map((med) => (
                <tr key={med.id} className={`transition-colors ${getRowStyle(med)}`}>
                  <td className="px-6 py-4">
                    <div className="font-bold text-gray-900 dark:text-white">{med.name}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{med.saltComposition}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5 uppercase tracking-wide">{med.manufacturer}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-mono text-xs text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded w-fit mb-1">{med.batchNumber}</div>
                    <div className={`text-xs font-medium ${new Date(med.expiryDate) < new Date() ? 'text-med-red' : 'text-gray-500'}`}>
                      EXP: {new Date(med.expiryDate).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-medium text-med-blue bg-med-blue/10 px-2.5 py-1 rounded-full border border-med-blue/20">
                      {med.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-700 dark:text-gray-300">
                    ₹{med.mrp.toFixed(2)}
                    <div className="text-xs text-gray-400 font-normal">GST: {med.gstPercentage}%</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <button 
                         onClick={() => onUpdateStock(med.id, med.stockCount - 1)}
                         className="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-600 dark:text-white transition-colors"
                      >
                        <Icons.Minus className="w-3 h-3" />
                      </button>
                      <span className={`w-12 text-center font-bold ${med.stockCount < med.minStockThreshold ? 'text-med-red' : 'text-gray-800 dark:text-white'}`}>
                        {med.stockCount}
                      </span>
                      <button 
                         onClick={() => onUpdateStock(med.id, med.stockCount + 1)}
                         className="w-8 h-8 flex items-center justify-center rounded-lg bg-med-blue hover:bg-med-deep text-white shadow-sm transition-colors"
                      >
                        <Icons.Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => onDeleteMedicine(med.id)}
                      className="text-gray-400 hover:text-med-red transition-colors p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                    >
                      <Icons.Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-med-surface rounded-2xl w-full max-w-2xl p-8 shadow-2xl overflow-y-auto max-h-[90vh] animate-fade-in-up">
            <div className="flex justify-between items-center mb-8 border-b dark:border-gray-800 pb-4">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Add Medicine</h3>
                <p className="text-gray-500 text-sm">Enter detailed pharmaceutical specifications</p>
              </div>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600"><Icons.X /></button>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
               {/* Form Fields */}
               <div className="col-span-2">
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Medicine Name</label>
                 <input className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.name} onChange={e => setNewMed({...newMed, name: e.target.value})} placeholder="e.g. Paracetamol 500mg" />
               </div>
               
               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Batch Number</label>
                 <input className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.batchNumber} onChange={e => setNewMed({...newMed, batchNumber: e.target.value})} />
               </div>
               
               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Manufacturer</label>
                 <input className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.manufacturer} onChange={e => setNewMed({...newMed, manufacturer: e.target.value})} />
               </div>

               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Expiry Date</label>
                 <input type="date" className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" onChange={e => setNewMed({...newMed, expiryDate: e.target.value})} />
               </div>

               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Stock Count</label>
                 <input type="number" className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.stockCount} onChange={e => setNewMed({...newMed, stockCount: parseInt(e.target.value)})} />
               </div>

               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">MRP (₹)</label>
                 <input type="number" className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.mrp} onChange={e => setNewMed({...newMed, mrp: parseFloat(e.target.value)})} />
               </div>

               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Category</label>
                 <select className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.type} onChange={e => setNewMed({...newMed, type: e.target.value as MedicineType})}>
                    {Object.values(MedicineType).map(t => <option key={t} value={t}>{t}</option>)}
                 </select>
               </div>

               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">GST/HSN Code</label>
                 <input type="number" className="w-full mt-1 p-3 border rounded-xl dark:bg-med-elevated dark:border-gray-700 dark:text-white" value={newMed.hsnCode || ''} onChange={e => setNewMed({...newMed, hsnCode: e.target.value})} placeholder="e.g. 3004" />
               </div>
            </div>

            <button onClick={handleAdd} className="w-full mt-8 bg-med-blue hover:bg-med-deep text-white font-bold py-4 rounded-xl shadow-lg transition-transform transform active:scale-95 flex items-center justify-center gap-2">
               <Icons.Save className="w-5 h-5" />
               <span>Save to Inventory</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// 6. Settings View (New)
const SettingsView = ({ user, darkMode, toggleTheme, onLogout }: any) => {
  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-med-deep dark:text-white">Settings</h2>

      {/* Profile Section */}
      <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Icons.User className="w-5 h-5 text-med-blue" />
          Profile Information
        </h3>
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
           <div className="w-24 h-24 rounded-full bg-med-blue flex items-center justify-center text-white font-bold text-3xl shadow-lg">
             {user.name.charAt(0)}
           </div>
           <div className="flex-1 space-y-4 w-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <label className="text-xs text-gray-500 uppercase font-bold">Full Name</label>
                    <div className="font-medium text-lg">{user.name}</div>
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 uppercase font-bold">Role</label>
                    <div><span className="bg-med-blue/10 text-med-blue px-2 py-1 rounded-md text-sm font-bold">{user.role}</span></div>
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 uppercase font-bold">Email</label>
                    <div className="font-medium">{user.email}</div>
                 </div>
                 <div>
                    <label className="text-xs text-gray-500 uppercase font-bold">Phone</label>
                    <div className="font-medium">{user.phone || 'N/A'}</div>
                 </div>
                 {user.pharmacyName && (
                   <div className="md:col-span-2">
                      <label className="text-xs text-gray-500 uppercase font-bold">Pharmacy Name</label>
                      <div className="font-medium">{user.pharmacyName}</div>
                   </div>
                 )}
                 {user.licenseNumber && (
                   <div className="md:col-span-2">
                      <label className="text-xs text-gray-500 uppercase font-bold">License Number</label>
                      <div className="font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded w-fit">{user.licenseNumber}</div>
                   </div>
                 )}
              </div>
           </div>
        </div>
      </div>

      {/* App Preferences */}
      <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
           <Icons.Settings className="w-5 h-5 text-gray-500" />
           App Preferences
        </h3>
        <div className="flex items-center justify-between py-4 border-b border-gray-100 dark:border-gray-800">
           <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${darkMode ? 'bg-purple-100 text-purple-600' : 'bg-orange-100 text-orange-600'}`}>
                 {darkMode ? <Icons.Moon className="w-5 h-5" /> : <Icons.Sun className="w-5 h-5" />}
              </div>
              <div>
                 <div className="font-medium">Dark Mode</div>
                 <div className="text-xs text-gray-500">Switch between light and dark themes</div>
              </div>
           </div>
           <button 
             onClick={toggleTheme}
             className={`w-14 h-8 rounded-full p-1 transition-colors duration-300 ease-in-out ${darkMode ? 'bg-med-blue' : 'bg-gray-300'}`}
           >
             <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300 ${darkMode ? 'translate-x-6' : 'translate-x-0'}`} />
           </button>
        </div>
      </div>

      {/* About & Support */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Icons.Activity className="w-5 h-5 text-med-green" />
              About App
            </h3>
            <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
               <p><span className="font-bold">Version:</span> 1.0.0 (Beta)</p>
               <p><span className="font-bold">Build:</span> 2023.10.25</p>
               <p>MedInvento is a comprehensive pharmacy inventory management system designed for efficiency and compliance.</p>
            </div>
         </div>

         <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Icons.ShieldCheck className="w-5 h-5 text-med-blue" />
              Help & Support
            </h3>
            <div className="space-y-3">
               <button className="w-full text-left px-4 py-3 rounded-xl bg-gray-50 dark:bg-med-elevated hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex justify-between items-center">
                  <span>Contact Support</span>
                  <Icons.ChevronRight className="w-4 h-4 text-gray-400" />
               </button>
               <button className="w-full text-left px-4 py-3 rounded-xl bg-gray-50 dark:bg-med-elevated hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex justify-between items-center">
                  <span>User Guide / FAQs</span>
                  <Icons.ChevronRight className="w-4 h-4 text-gray-400" />
               </button>
            </div>
         </div>
      </div>

      {/* Logout */}
      <div className="pt-4">
         <button 
           onClick={onLogout}
           className="w-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-bold py-4 rounded-xl border border-red-100 dark:border-red-900/30 hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors flex items-center justify-center gap-2"
         >
            <Icons.LogOut className="w-5 h-5" />
            Sign Out
         </button>
      </div>
    </div>
  )
}

// 7. Login View (Restored & Enhanced)
const LoginView = ({ onLogin }: { onLogin: (u: User) => void }) => {
  const [method, setMethod] = useState<'EMAIL' | 'PHONE'>('EMAIL');
  const [role, setRole] = useState<UserRole>(UserRole.OWNER);
  const [formData, setFormData] = useState({ email: '', password: '', phone: '', otp: '' });
  
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = MOCK_USERS.find(u => u.role === role);
    if(user) onLogin(user);
    else onLogin({...MOCK_USERS[0], role}); // Fallback
  };

  const fillDemo = (r: UserRole) => {
    const user = MOCK_USERS.find(u => u.role === r);
    if(user) {
      setRole(r);
      setFormData({ ...formData, email: user.email, password: 'password123' });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-med-dark p-4">
      <div className="w-full max-w-5xl bg-white dark:bg-med-surface rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        {/* Left Side - Brand */}
        <div className="md:w-1/2 bg-gradient-to-br from-med-deep to-med-blue p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
               <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                 <Icons.Activity className="w-8 h-8" />
               </div>
               <span className="text-2xl font-bold tracking-tight">MedInvento Pro</span>
            </div>
            <h1 className="text-4xl font-bold leading-tight mb-4">
              Pharmacy Management <br/> Reimagined.
            </h1>
            <p className="text-blue-100 text-lg">
              Complete inventory control, compliance tracking, and business analytics in one secure platform.
            </p>
          </div>

          <div className="relative z-10 space-y-4">
             <div className="flex items-center gap-4 bg-white/10 p-4 rounded-xl backdrop-blur-md">
               <Icons.ShieldCheck className="w-8 h-8 text-med-aqua" />
               <div>
                 <p className="font-bold">Govt. Compliant</p>
                 <p className="text-xs text-blue-100">Automatic Sync with CDSCO</p>
               </div>
             </div>
             <div className="flex items-center gap-4 bg-white/10 p-4 rounded-xl backdrop-blur-md">
               <Icons.Zap className="w-8 h-8 text-yellow-300" />
               <div>
                 <p className="font-bold">Fast Barcode Scan</p>
                 <p className="text-xs text-blue-100">ML-Powered Batch Entry</p>
               </div>
             </div>
          </div>
          
          <Icons.Activity className="absolute -bottom-20 -right-20 w-96 h-96 text-white opacity-5" />
        </div>

        {/* Right Side - Form */}
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
          <div className="max-w-md mx-auto w-full">
             <div className="flex gap-4 mb-8">
                <button 
                  onClick={() => setMethod('EMAIL')}
                  className={`flex-1 py-3 font-bold text-sm rounded-xl transition-all border ${method === 'EMAIL' ? 'border-med-blue bg-med-blue/5 text-med-blue' : 'border-gray-200 text-gray-500 dark:border-gray-700'}`}
                >
                  Email Login
                </button>
                <button 
                  onClick={() => setMethod('PHONE')}
                  className={`flex-1 py-3 font-bold text-sm rounded-xl transition-all border ${method === 'PHONE' ? 'border-med-blue bg-med-blue/5 text-med-blue' : 'border-gray-200 text-gray-500 dark:border-gray-700'}`}
                >
                  Phone OTP
                </button>
             </div>

             <form onSubmit={handleLogin} className="space-y-5">
               <div>
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Select Role</label>
                 <div className="grid grid-cols-2 gap-2 mt-2">
                   {[UserRole.OWNER, UserRole.GOVT].map(r => (
                     <button
                       key={r}
                       type="button"
                       onClick={() => setRole(r)}
                       className={`py-2 px-1 text-[10px] md:text-xs font-bold rounded-lg transition-all ${role === r ? 'bg-med-deep text-white shadow-lg' : 'bg-gray-100 dark:bg-gray-800 text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
                     >
                       {r === UserRole.GOVT ? 'GOVT. AUTH' : r}
                     </button>
                   ))}
                 </div>
               </div>

               {method === 'EMAIL' ? (
                 <>
                   <div>
                     <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Email</label>
                     <input 
                        type="email" 
                        className="w-full mt-1 p-4 bg-gray-50 dark:bg-med-elevated border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-med-blue focus:outline-none dark:text-white"
                        placeholder="name@pharmacy.com"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                     />
                   </div>
                   <div>
                     <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Password</label>
                     <input 
                        type="password" 
                        className="w-full mt-1 p-4 bg-gray-50 dark:bg-med-elevated border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-med-blue focus:outline-none dark:text-white"
                        placeholder="••••••••"
                        value={formData.password}
                        onChange={e => setFormData({...formData, password: e.target.value})}
                     />
                     <button type="button" className="text-xs text-med-blue font-bold mt-2 float-right hover:text-med-deep">Forgot Password?</button>
                   </div>
                 </>
               ) : (
                 <div>
                   <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Mobile Number</label>
                   <input 
                      type="tel" 
                      className="w-full mt-1 p-4 bg-gray-50 dark:bg-med-elevated border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-med-blue focus:outline-none dark:text-white"
                      placeholder="+91 98765 43210"
                   />
                 </div>
               )}

               <button className="w-full bg-med-blue hover:bg-med-deep text-white font-bold py-4 rounded-xl shadow-xl shadow-med-blue/30 transition-all transform active:scale-95 text-lg flex justify-center items-center">
                 Secure Login <Icons.ArrowRight className="ml-2 w-5 h-5" />
               </button>
             </form>

             <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800">
               <p className="text-center text-xs text-gray-400 font-bold uppercase mb-4">Quick Demo Access (Dev Only)</p>
               <div className="flex justify-center gap-4">
                 <button onClick={() => fillDemo(UserRole.OWNER)} className="text-xs text-med-blue font-bold bg-blue-50 dark:bg-blue-900/20 px-3 py-2 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors">Owner</button>
                 <button onClick={() => fillDemo(UserRole.GOVT)} className="text-xs text-med-red font-bold bg-red-50 dark:bg-red-900/20 px-3 py-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors">Govt</button>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- MAIN APP COMPONENT ---

const App = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>('LOGIN');
  const [medicines, setMedicines] = useState<Medicine[]>(INITIAL_MEDICINES);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [scannedResult, setScannedResult] = useState<Medicine | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  // Computed stats and lists for Dashboard
  const { lowStockItems, expiringSoonItems, stats } = useMemo(() => {
    const totalStock = medicines.reduce((acc, med) => acc + med.stockCount, 0);
    const expiredCount = medicines.filter(m => new Date(m.expiryDate) < new Date()).length;
    
    // Filter for low stock
    const lowStockItems = medicines.filter(m => m.stockCount < m.minStockThreshold);
    
    // Filter for expiring soon (0 to 90 days)
    const expiringSoonItems = medicines.filter(m => {
      const days = (new Date(m.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
      return days > 0 && days < 90;
    }).sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
    
    return {
      lowStockItems,
      expiringSoonItems,
      stats: {
        totalMedicines: medicines.length,
        totalStock,
        lowStockCount: lowStockItems.length,
        expiredCount,
        expiringSoonCount: expiringSoonItems.length
      }
    };
  }, [medicines]);

  useEffect(() => {
    // Apply theme
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleTheme = () => setDarkMode(!darkMode);

  const handleLogin = (u: User) => {
    setUser(u);
    setCurrentView('DASHBOARD');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('LOGIN');
  };

  const handleAddMedicine = (med: Medicine) => {
    setMedicines([...medicines, med]);
  };

  const handleDeleteMedicine = (id: string) => {
    setMedicines(medicines.filter(m => m.id !== id));
  };

  const handleUpdateStock = (id: string, count: number) => {
    if (count < 0) return;
    setMedicines(medicines.map(m => m.id === id ? { ...m, stockCount: count } : m));
  };

  const handleScan = (code: string) => {
    setShowScanner(false);
    const found = medicines.find(m => m.barcode === code);
    if (found) {
      setScannedResult(found);
    } else {
      alert(`Barcode ${code} scanned but no product found.`);
    }
  };

  if (!user) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden font-sans text-gray-900 dark:text-white">
      <Sidebar 
        user={user}
        currentView={currentView}
        onChangeView={(v) => { setCurrentView(v); setScannedResult(null); }}
        onLogout={handleLogout}
        isOpen={sidebarOpen}
        toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />
      
      {showScanner && (
        <BarcodeScanner 
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Header */}
        <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur border-b border-gray-100 dark:border-gray-800 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-4">
             <button onClick={() => setSidebarOpen(true)} className="md:hidden text-gray-500">
               <Icons.Menu />
             </button>
             <h2 className="text-xl font-bold capitalize">{currentView.replace('_', ' ').toLowerCase()}</h2>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:block text-right">
              <div className="text-sm font-bold">{user.pharmacyName}</div>
              <div className="text-xs text-gray-500">Lic: {user.licenseNumber || 'N/A'}</div>
            </div>
            <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full relative">
               <Icons.Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
               {stats.expiringSoonCount > 0 && (
                 <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 border-2 border-white dark:border-gray-900 rounded-full"></span>
               )}
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          {currentView === 'DASHBOARD' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 <StatCard 
                   title="Total Medicines" 
                   value={stats.totalMedicines} 
                   icon={Icons.Package} 
                   colorClass="bg-blue-500" 
                 />
                 <StatCard 
                   title="Low Stock Alerts" 
                   value={stats.lowStockCount} 
                   icon={Icons.AlertOctagon} 
                   colorClass="bg-red-500"
                   textColor="text-red-600"
                 />
                 <StatCard 
                   title="Expiring Soon" 
                   value={stats.expiringSoonCount} 
                   subtext="In next 90 days"
                   icon={Icons.Calendar} 
                   colorClass="bg-orange-500"
                   textColor="text-orange-600"
                 />
                 <StatCard 
                   title="Total Stock Units" 
                   value={stats.totalStock.toLocaleString()} 
                   icon={Icons.Database} 
                   colorClass="bg-emerald-500" 
                 />
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
                   <h3 className="font-bold text-lg mb-6">Stock Categories</h3>
                   <div className="h-64">
                     <ResponsiveContainer width="100%" height="100%">
                       <BarChart data={[
                         { name: 'Tablet', count: medicines.filter(m => m.type === MedicineType.TABLET).length },
                         { name: 'Syrup', count: medicines.filter(m => m.type === MedicineType.SYRUP).length },
                         { name: 'Injection', count: medicines.filter(m => m.type === MedicineType.INJECTION).length },
                         { name: 'Topical', count: medicines.filter(m => m.type === MedicineType.CREAM || m.type === MedicineType.OINTMENT).length },
                       ]}>
                         <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.1} />
                         <XAxis dataKey="name" axisLine={false} tickLine={false} />
                         <YAxis axisLine={false} tickLine={false} />
                         <Tooltip />
                         <Bar dataKey="count" fill="#3B82F6" radius={[4, 4, 0, 0]} barSize={40} />
                       </BarChart>
                     </ResponsiveContainer>
                   </div>
                </div>
                
                <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
                   <h3 className="font-bold text-lg mb-6">Quick Actions</h3>
                   <div className="space-y-3">
                     <button onClick={() => setCurrentView('INVENTORY')} className="w-full p-4 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-300 flex items-center justify-between hover:bg-blue-100 transition-colors">
                       <span className="font-semibold">Add New Stock</span>
                       <Icons.Plus className="w-5 h-5" />
                     </button>
                     <button onClick={() => setCurrentView('SCANNER')} className="w-full p-4 rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-300 flex items-center justify-between hover:bg-purple-100 transition-colors">
                       <span className="font-semibold">Scan Barcode</span>
                       <Icons.ScanLine className="w-5 h-5" />
                     </button>
                     <button className="w-full p-4 rounded-xl bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-300 flex items-center justify-between hover:bg-green-100 transition-colors">
                       <span className="font-semibold">Generate Report</span>
                       <Icons.FileText className="w-5 h-5" />
                     </button>
                   </div>
                </div>
              </div>

              {/* Alert Lists Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Low Stock Section */}
                <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-lg text-med-red">Low Stock Alerts</h3>
                    <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full font-bold">{lowStockItems.length} Items</span>
                  </div>
                  <div className="overflow-y-auto max-h-64 pr-2">
                    {lowStockItems.length === 0 ? (
                      <div className="text-center py-8 text-gray-400 flex flex-col items-center">
                        <Icons.CheckCircle className="w-8 h-8 mb-2 opacity-50 text-med-green" />
                        <p className="text-sm">Stock levels are healthy.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {lowStockItems.map(med => (
                          <div key={med.id} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/10 rounded-xl border border-red-100 dark:border-red-900/20">
                            <div>
                               <div className="font-bold text-sm text-gray-900 dark:text-white">{med.name}</div>
                               <div className="text-xs text-gray-500">Batch: <span className="font-mono">{med.batchNumber}</span></div>
                            </div>
                            <div className="text-right">
                               <div className="text-med-red font-bold text-sm">{med.stockCount} left</div>
                               <div className="text-xs text-gray-400">Threshold: {med.minStockThreshold}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Expiring Soon Section */}
                <div className="bg-white dark:bg-med-surface rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-lg text-med-orange">Expiring Soon (90 Days)</h3>
                    <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full font-bold">{expiringSoonItems.length} Items</span>
                  </div>
                  <div className="overflow-y-auto max-h-64 pr-2">
                    {expiringSoonItems.length === 0 ? (
                      <div className="text-center py-8 text-gray-400 flex flex-col items-center">
                        <Icons.CheckCircle className="w-8 h-8 mb-2 opacity-50 text-med-green" />
                        <p className="text-sm">No items expiring soon.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {expiringSoonItems.map(med => {
                          const days = Math.ceil((new Date(med.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
                          return (
                            <div key={med.id} className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/10 rounded-xl border border-orange-100 dark:border-orange-900/20">
                              <div>
                                 <div className="font-bold text-sm text-gray-900 dark:text-white">{med.name}</div>
                                 <div className="text-xs text-gray-500">Batch: <span className="font-mono">{med.batchNumber}</span></div>
                              </div>
                              <div className="text-right">
                                 <div className="text-med-orange font-bold text-sm">{days} Days</div>
                                 <div className="text-xs text-gray-400">{new Date(med.expiryDate).toLocaleDateString()}</div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentView === 'INVENTORY' && (
            <InventoryView 
              medicines={medicines}
              onAddMedicine={handleAddMedicine}
              onDeleteMedicine={handleDeleteMedicine}
              onUpdateStock={handleUpdateStock}
              currentUser={user}
            />
          )}

          {currentView === 'SCANNER' && (
             <div className="flex flex-col items-center justify-center h-full max-h-[70vh] text-center space-y-6 animate-fade-in">
                {!scannedResult ? (
                  <>
                    <div className="w-32 h-32 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center shadow-inner">
                      <Icons.ScanLine className="w-16 h-16 text-gray-400" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Scanner Mode</h2>
                      <p className="text-gray-500 mt-2">Use your device camera to scan medicine barcodes</p>
                    </div>
                    <button 
                      onClick={() => setShowScanner(true)}
                      className="px-8 py-4 bg-med-blue text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-med-blue/20 flex items-center gap-2"
                    >
                      <Icons.Camera className="w-5 h-5" />
                      Enable Camera Access
                    </button>
                  </>
                ) : (
                  <div className="w-full max-w-lg bg-white dark:bg-med-surface p-8 rounded-3xl shadow-2xl border border-med-blue/20 animate-fade-in-up text-left">
                     <div className="flex justify-between items-start mb-6">
                        <div>
                          <span className="text-xs font-bold text-med-blue bg-med-blue/10 px-3 py-1 rounded-full">SCANNED SUCCESSFULLY</span>
                          <h2 className="text-2xl font-bold mt-2 text-gray-900 dark:text-white">{scannedResult.name}</h2>
                          <p className="text-sm text-gray-500">{scannedResult.saltComposition}</p>
                        </div>
                        <button onClick={() => setScannedResult(null)} className="text-gray-400 hover:text-gray-600"><Icons.X /></button>
                     </div>
                     
                     <div className="grid grid-cols-2 gap-4 mb-8">
                        <div className="p-4 bg-gray-50 dark:bg-med-elevated rounded-xl">
                           <p className="text-xs text-gray-500 font-bold uppercase">Batch Number</p>
                           <p className="font-mono text-lg font-bold">{scannedResult.batchNumber}</p>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-med-elevated rounded-xl">
                           <p className="text-xs text-gray-500 font-bold uppercase">Expiry Date</p>
                           <p className={`font-mono text-lg font-bold ${new Date(scannedResult.expiryDate) < new Date() ? 'text-red-500' : 'text-green-500'}`}>
                              {new Date(scannedResult.expiryDate).toLocaleDateString()}
                           </p>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-med-elevated rounded-xl">
                           <p className="text-xs text-gray-500 font-bold uppercase">Stock</p>
                           <p className="font-mono text-lg font-bold">{scannedResult.stockCount}</p>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-med-elevated rounded-xl">
                           <p className="text-xs text-gray-500 font-bold uppercase">MRP</p>
                           <p className="font-mono text-lg font-bold">₹{scannedResult.mrp}</p>
                        </div>
                     </div>

                     <div className="flex gap-3">
                        <button onClick={() => { setCurrentView('INVENTORY'); setScannedResult(null); }} className="flex-1 bg-med-blue text-white py-3 rounded-xl font-bold hover:bg-med-deep transition-colors">
                           View in Inventory
                        </button>
                        <button onClick={() => { setScannedResult(null); setShowScanner(true); }} className="flex-1 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white py-3 rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                           Scan Again
                        </button>
                     </div>
                  </div>
                )}
             </div>
          )}

          {currentView === 'GOVT_PORTAL' && (
             <GovernmentPortalView allMedicines={medicines} />
          )}

          {currentView === 'SETTINGS' && (
             <SettingsView 
               user={user} 
               darkMode={darkMode} 
               toggleTheme={toggleTheme} 
               onLogout={handleLogout} 
             />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;