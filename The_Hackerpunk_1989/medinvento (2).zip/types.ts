export enum UserRole {
  OWNER = 'OWNER',
  EMPLOYEE = 'EMPLOYEE',
  GOVT = 'GOVT'
}

export enum MedicineType {
  TABLET = 'Tablet',
  CAPSULE = 'Capsule',
  SYRUP = 'Syrup',
  INJECTION = 'Injection',
  CREAM = 'Cream',
  OINTMENT = 'Ointment',
  DROPS = 'Drops',
  POWDER = 'Powder',
  OTHER = 'Other'
}

export interface Medicine {
  id: string;
  name: string;
  saltComposition: string;
  manufacturer: string;
  batchNumber: string;
  mrp: number;
  sellingPrice: number;
  stockCount: number;
  expiryDate: string; // ISO Date string
  manufacturingDate: string;
  type: MedicineType;
  barcode: string;
  gstPercentage: number;
  hsnCode?: string; // Added field for GST/HSN Code
  scheduleCategory: string; // e.g., H, H1, X
  addedBy: string;
  lastUpdated: string;
  minStockThreshold: number;
}

export interface InventoryLog {
  id: string;
  medicineName: string;
  action: 'ADDED' | 'REMOVED' | 'UPDATED' | 'SOLD';
  quantity: number;
  updatedBy: string;
  timestamp: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  pharmacyName?: string;
  licenseNumber?: string;
  phone?: string;
}

export interface ComplianceReport {
  id: string;
  generatedDate: string;
  score: number;
  expiredCount: number;
  missingFieldsCount: number;
  status: 'Pass' | 'Fail' | 'Warning';
}

export type ViewState = 
  | 'LOGIN' 
  | 'DASHBOARD' 
  | 'INVENTORY' 
  | 'SCANNER' 
  | 'GOVT_PORTAL' 
  | 'SETTINGS';